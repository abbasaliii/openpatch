"use strict";
(() => {
  // src/registry/patches/civic-apply.openpatch.json
  var civic_apply_openpatch_default = {
    schemaVersion: 1,
    id: "org.openpatch.civicapply-accessible-draft",
    name: "CivicApply: accessible & autosaved",
    summary: "Repairs the mobile application flow, preserves unfinished progress, adds accessible validation, and removes the obstructive survey.",
    version: "1.0.0",
    author: { name: "OpenPatch Community", verified: true },
    match: {
      hosts: ["localhost", "127.0.0.1"],
      paths: ["/demo/*", "/demo/"]
    },
    capabilities: [
      "layout",
      "accessibility",
      "local-storage",
      "keyboard-navigation",
      "validation",
      "hide-elements",
      "reorganize"
    ],
    operations: [
      {
        id: "hide-obstructive-survey",
        type: "hide",
        selector: ".survey-wall"
      },
      {
        id: "hide-conflicting-save-state",
        type: "hide",
        selector: ".draft-badge"
      },
      {
        id: "repair-page-width",
        type: "style",
        selector: ".application-shell",
        styles: {
          "max-width": "900px",
          width: "calc(100% - 32px)",
          margin: "0 auto",
          "grid-template-columns": "minmax(0, 1fr)",
          gap: "32px"
        }
      },
      {
        id: "repair-mobile-layout",
        type: "style",
        selector: ".application-shell",
        when: { maxWidth: 760 },
        styles: {
          display: "flex",
          "flex-direction": "column",
          width: "calc(100% - 24px)",
          gap: "16px"
        }
      },
      {
        id: "mobile-form-spacing",
        type: "style",
        selector: ".application-main",
        when: { maxWidth: 760 },
        styles: {
          padding: "20px",
          "border-radius": "18px"
        }
      },
      {
        id: "mobile-header-width",
        type: "style",
        selector: ".government-header, .session-warning",
        when: { maxWidth: 760 },
        styles: {
          width: "100%",
          "max-width": "100%",
          "padding-left": "16px",
          "padding-right": "16px",
          "flex-wrap": "wrap"
        }
      },
      {
        id: "mobile-hide-agency-nav",
        type: "style",
        selector: ".government-header nav",
        when: { maxWidth: 760 },
        styles: { display: "none" }
      },
      {
        id: "mobile-content-width",
        type: "style",
        selector: ".application-heading, .progress-steps",
        when: { maxWidth: 760 },
        styles: {
          width: "calc(100% - 24px)",
          "max-width": "100%",
          "margin-left": "auto",
          "margin-right": "auto",
          "overflow-x": "auto"
        }
      },
      {
        id: "mobile-progress-gaps",
        type: "style",
        selector: ".progress-steps > i",
        when: { maxWidth: 760 },
        styles: {
          width: "42px",
          "margin-left": "6px",
          "margin-right": "6px"
        }
      },
      {
        id: "readable-fields",
        type: "style",
        selector: ".field-row",
        styles: {
          display: "grid",
          "grid-template-columns": "minmax(0, 1fr)",
          gap: "8px",
          "margin-bottom": "20px"
        }
      },
      {
        id: "move-help-before-form",
        type: "move",
        selector: ".help-card",
        target: "#benefits-form",
        position: "before"
      },
      {
        id: "help-card-layout",
        type: "style",
        selector: ".help-card",
        styles: {
          "margin-bottom": "20px",
          "background-color": "#effcf6",
          "border-color": "#b7ebd0"
        }
      },
      {
        id: "progress-semantics",
        type: "attributes",
        selector: "#progress-steps",
        attributes: {
          role: "tablist",
          "aria-label": "Application progress"
        }
      },
      {
        id: "progress-tabs",
        type: "attributes",
        selector: "#progress-steps button",
        attributes: { role: "tab" }
      },
      {
        id: "progress-keyboard",
        type: "keyboardNavigation",
        container: "#progress-steps",
        items: "button",
        orientation: "horizontal",
        wrap: true
      },
      {
        id: "label-required-email",
        type: "attributes",
        selector: "#email",
        attributes: {
          "aria-required": "true",
          autocomplete: "email",
          inputmode: "email"
        }
      },
      {
        id: "label-required-name",
        type: "attributes",
        selector: "#full-name",
        attributes: {
          "aria-required": "true",
          autocomplete: "name"
        }
      },
      {
        id: "persist-draft",
        type: "persistForm",
        selector: "#benefits-form",
        key: "housing-support-draft-v1",
        include: ["input", "select", "textarea"],
        statusText: "Draft saved on this device"
      },
      {
        id: "accessible-validation",
        type: "validation",
        selector: "#benefits-form",
        fields: [
          {
            selector: "#full-name",
            rules: [
              { kind: "required", message: "Enter your full name so we can continue." },
              { kind: "minLength", value: 3, message: "Your full name must contain at least 3 characters." }
            ]
          },
          {
            selector: "#email",
            rules: [
              { kind: "required", message: "Enter an email address for application updates." },
              { kind: "email", message: "Enter an email address in the format name@example.com." }
            ]
          },
          {
            selector: "#household-size",
            rules: [
              { kind: "required", message: "Select the number of people in your household." }
            ]
          },
          {
            selector: "#address",
            rules: [
              { kind: "required", message: "Enter your current street address." }
            ]
          }
        ]
      }
    ],
    verify: [
      { type: "exists", selector: "#benefits-form", min: 1, max: 1 },
      { type: "exists", selector: ".survey-wall", min: 1, max: 1 },
      { type: "exists", selector: "#progress-steps button", min: 3, max: 3 },
      { type: "attribute", selector: "#email", name: "aria-required", value: "true" }
    ],
    changelog: "Initial community repair: responsive layout, draft recovery, keyboard progress navigation, accessible field errors, and removal of the blocking survey."
  };

  // src/extension/popup.ts
  var patch = civic_apply_openpatch_default;
  var byId = (id) => document.getElementById(id);
  var host = byId("site-host");
  var icon = byId("site-icon");
  var matchDot = byId("match-dot");
  var card = byId("patch-card");
  var empty = byId("empty-state");
  var toggle = byId("patch-toggle");
  var CAPABILITY_LABELS = {
    layout: "Change allowlisted layout and visual properties",
    accessibility: "Add ARIA and safe interaction attributes",
    "local-storage": "Save non-sensitive form fields on this device",
    "keyboard-navigation": "Add arrow-key navigation within matched controls",
    validation: "Add local, accessible field validation",
    "hide-elements": "Hide explicitly matched obstructive elements",
    reorganize: "Move matched elements within the same page"
  };
  async function activeTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0];
  }
  function renderState(state) {
    if (!state.matched) return;
    matchDot.classList.add("active");
    card.hidden = false;
    empty.hidden = true;
    byId("patch-name").textContent = state.patch.name;
    byId("patch-version").textContent = `v${state.patch.version}`;
    byId("patch-summary").textContent = state.patch.summary;
    byId("patch-author").textContent = state.patch.author.name;
    toggle.checked = state.enabled;
    byId("toggle-title").textContent = state.enabled ? "Repair is active" : "Apply this repair";
    byId("permissions-list").replaceChildren(...state.patch.capabilities.map((capability) => {
      const item = document.createElement("li");
      item.textContent = CAPABILITY_LABELS[capability] ?? capability;
      return item;
    }));
    if (state.enabled && state.health) {
      byId("health-title").textContent = `${state.health.healthy}/${state.health.total} operations healthy`;
      byId("health-detail").textContent = state.health.applied ? "All selectors matched \xB7 patch applied safely" : "Some selectors may need an update";
      byId("health-row").classList.toggle("warning", !state.health.applied);
    }
  }
  async function init() {
    const tab = await activeTab();
    let hostname = "This page";
    try {
      hostname = new URL(tab.url ?? "").hostname || hostname;
    } catch {
    }
    host.textContent = hostname;
    icon.textContent = hostname.charAt(0).toUpperCase();
    if (!tab.id) return;
    try {
      const state = await chrome.tabs.sendMessage(tab.id, { type: "OPENPATCH_GET_STATE" });
      renderState(state);
    } catch {
      empty.hidden = false;
    }
  }
  toggle.addEventListener("change", async () => {
    toggle.disabled = true;
    const stored = await chrome.storage.local.get("enabledPatches");
    const enabledPatches = stored.enabledPatches ?? {};
    enabledPatches[patch.id] = toggle.checked;
    await chrome.storage.local.set({ enabledPatches });
    const tab = await activeTab();
    if (tab.id) await chrome.tabs.reload(tab.id);
    window.close();
  });
  void init();
})();
//# sourceMappingURL=popup.js.map
