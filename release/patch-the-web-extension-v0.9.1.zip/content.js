"use strict";
(() => {
  // src/registry/patches/civic-apply.patch-the-web.json
  var civic_apply_patch_the_web_default = {
    schemaVersion: 1,
    id: "org.patchtheweb.civicapply-accessible-draft",
    name: "CivicApply: accessible & autosaved",
    summary: "Repairs the mobile application flow, preserves unfinished progress, adds accessible validation, and removes the obstructive survey.",
    version: "1.2.0",
    author: { name: "Patch the Web Community", verified: false },
    match: {
      hosts: ["localhost", "127.0.0.1", "patch-the-web.vercel.app"],
      paths: ["/demo/*"]
    },
    capabilities: [
      "layout",
      "accessibility",
      "local-storage",
      "keyboard-navigation",
      "validation",
      "hide-elements",
      "reorganize"
    ],
    operations: [
      {
        id: "hide-obstructive-survey",
        type: "hide",
        selector: ".survey-wall"
      },
      {
        id: "hide-conflicting-save-state",
        type: "hide",
        selector: ".draft-badge"
      },
      {
        id: "repair-page-width",
        type: "style",
        selector: ".application-shell",
        styles: {
          "max-width": "900px",
          width: "calc(100% - 32px)",
          margin: "0 auto",
          "grid-template-columns": "minmax(0, 1fr)",
          gap: "32px"
        }
      },
      {
        id: "repair-mobile-layout",
        type: "style",
        selector: ".application-shell",
        when: { maxWidth: 760 },
        styles: {
          display: "flex",
          "flex-direction": "column",
          width: "calc(100% - 24px)",
          gap: "16px"
        }
      },
      {
        id: "mobile-form-spacing",
        type: "style",
        selector: ".application-main",
        when: { maxWidth: 760 },
        styles: {
          padding: "20px",
          "border-radius": "18px"
        }
      },
      {
        id: "mobile-header-width",
        type: "style",
        selector: ".government-header, .session-warning",
        when: { maxWidth: 760 },
        styles: {
          width: "100%",
          "max-width": "100%",
          "padding-left": "16px",
          "padding-right": "16px",
          "flex-wrap": "wrap"
        }
      },
      {
        id: "mobile-preserve-agency-nav",
        type: "style",
        selector: ".government-header nav",
        when: { maxWidth: 760 },
        styles: {
          display: "flex",
          order: "3",
          width: "100%",
          "margin-left": "0",
          "overflow-x": "auto",
          "padding-bottom": "10px"
        }
      },
      {
        id: "mobile-content-width",
        type: "style",
        selector: ".application-heading, .progress-steps",
        when: { maxWidth: 760 },
        styles: {
          width: "calc(100% - 24px)",
          "max-width": "100%",
          "margin-left": "auto",
          "margin-right": "auto",
          "overflow-x": "auto"
        }
      },
      {
        id: "mobile-progress-gaps",
        type: "style",
        selector: ".progress-steps > i",
        when: { maxWidth: 760 },
        styles: {
          width: "42px",
          "margin-left": "6px",
          "margin-right": "6px"
        }
      },
      {
        id: "readable-fields",
        type: "style",
        selector: ".field-row",
        styles: {
          display: "grid",
          "grid-template-columns": "minmax(0, 1fr)",
          gap: "8px",
          "margin-bottom": "20px"
        }
      },
      {
        id: "move-help-before-form",
        type: "move",
        selector: ".help-card",
        target: "#benefits-form",
        position: "before"
      },
      {
        id: "help-card-layout",
        type: "style",
        selector: ".help-card",
        styles: {
          "margin-bottom": "20px",
          "background-color": "#effcf6",
          "border-color": "#b7ebd0"
        }
      },
      {
        id: "progress-semantics",
        type: "attributes",
        selector: "#progress-steps",
        attributes: {
          role: "group",
          "aria-label": "Application progress"
        }
      },
      {
        id: "progress-keyboard",
        type: "keyboardNavigation",
        container: "#progress-steps",
        items: "button",
        orientation: "horizontal",
        wrap: true
      },
      {
        id: "label-required-email",
        type: "attributes",
        selector: "#email",
        attributes: {
          "aria-required": "true",
          autocomplete: "email",
          inputmode: "email"
        }
      },
      {
        id: "label-required-name",
        type: "attributes",
        selector: "#full-name",
        attributes: {
          "aria-required": "true",
          autocomplete: "name"
        }
      },
      {
        id: "label-other-required-fields",
        type: "attributes",
        selector: "#household-size, #address",
        attributes: { "aria-required": "true" }
      },
      {
        id: "persist-draft",
        type: "persistForm",
        selector: "#benefits-form",
        key: "housing-support-draft-v1",
        include: ["input", "select", "textarea"],
        ttlMinutes: 1440,
        statusText: "Draft saved on this device for 24 hours"
      },
      {
        id: "accessible-validation",
        type: "validation",
        selector: "#benefits-form",
        fields: [
          {
            selector: "#full-name",
            rules: [
              { kind: "required", message: "Enter your full name so we can continue." },
              { kind: "minLength", value: 3, message: "Your full name must contain at least 3 characters." }
            ]
          },
          {
            selector: "#email",
            rules: [
              { kind: "required", message: "Enter an email address for application updates." },
              { kind: "email", message: "Enter an email address in the format name@example.com." }
            ]
          },
          {
            selector: "#household-size",
            rules: [
              { kind: "required", message: "Select the number of people in your household." }
            ]
          },
          {
            selector: "#address",
            rules: [
              { kind: "required", message: "Enter your current street address." }
            ]
          }
        ]
      }
    ],
    verify: [
      { type: "exists", selector: "#benefits-form", min: 1, max: 1 },
      { type: "exists", selector: "#progress-steps button", min: 3, max: 3 },
      { type: "exists", selector: ".help-card", min: 1, max: 1 },
      { type: "exists", selector: ".patch-the-web-save-status", min: 1, max: 1 },
      { type: "attribute", selector: ".survey-wall", name: "aria-hidden", value: "true" },
      { type: "attribute", selector: ".draft-badge", name: "aria-hidden", value: "true" },
      { type: "attribute", selector: "#progress-steps", name: "role", value: "group" },
      { type: "attribute", selector: "#email", name: "aria-required", value: "true" },
      { type: "attribute", selector: "#household-size", name: "aria-required", value: "true" },
      { type: "attribute", selector: "#address", name: "aria-required", value: "true" }
    ],
    changelog: "Added the permanent public demo domain while preserving the hardened mobile navigation, required-field semantics, 24-hour draft expiry, and publication assertions."
  };

  // src/core/table-filter.ts
  var MAX_HEADERS = 20;
  var MAX_ROWS = 100;
  var normalize = (value) => (value ?? "").replace(/\s+/g, " ").trim();
  function inspectTableColumnFilter(operation, root = document) {
    try {
      const candidates = [...root.querySelectorAll(operation.selector)];
      if (candidates.length !== 1 || candidates[0].tagName !== "TABLE") {
        return { healthy: false, matched: candidates.length, detail: "expected exactly one table" };
      }
      const table = candidates[0];
      const headers = [...table.querySelectorAll(operation.headerSelector)];
      if (headers.length < 2 || headers.length > MAX_HEADERS) {
        return { healthy: false, matched: headers.length, detail: "expected 2-20 table headers" };
      }
      const headerMatches = headers.filter((header) => normalize(header.textContent) === operation.headerText);
      if (headerMatches.length !== 1) {
        return { healthy: false, matched: headerMatches.length, detail: "expected one exact header match" };
      }
      const columnIndex = headers.indexOf(headerMatches[0]);
      const rows = [...table.querySelectorAll(operation.rowSelector)];
      if (rows.length === 0 || rows.length > MAX_ROWS) {
        return { healthy: false, matched: rows.length, detail: "expected 1-100 bounded table rows" };
      }
      const matrixRows = rows.filter((row) => {
        const cells = [...row.children].filter((cell) => cell.tagName === "TH" || cell.tagName === "TD");
        return cells.length === headers.length;
      });
      const dataRows = matrixRows.filter((row) => [...row.children].some((cell) => cell.tagName === "TD"));
      if (dataRows.length === 0) return { healthy: false, matched: 0, detail: "no bounded data rows found" };
      const matchingRows = [];
      const hiddenRows = [];
      for (const row of dataRows) {
        const cells = [...row.children].filter((cell) => cell.tagName === "TH" || cell.tagName === "TD");
        const markerCount = cells[columnIndex].querySelectorAll(operation.markerSelector).length;
        if (markerCount > 1) return { healthy: false, matched: markerCount, detail: "expected at most one marker per target cell" };
        (markerCount === 1 ? matchingRows : hiddenRows).push(row);
      }
      if (matchingRows.length === 0) return { healthy: false, matched: 0, detail: "no matching rows found" };
      return {
        healthy: true,
        matched: matchingRows.length,
        detail: `${matchingRows.length} matching rows; ${hiddenRows.length} excluded rows`,
        table,
        header: headerMatches[0],
        matchingRows,
        hiddenRows,
        matrixRows,
        columnIndex
      };
    } catch {
      return { healthy: false, matched: 0, detail: "table selector inspection failed" };
    }
  }

  // src/core/public-table-search.ts
  var normalize2 = (value) => (value ?? "").replace(/\s+/g, " ").trim();
  function inspectPublicTableSearch(operation, document2) {
    try {
      const matches2 = [...document2.querySelectorAll(operation.selector)];
      const tables = matches2.filter((element) => element.tagName === "TABLE");
      if (matches2.length !== tables.length || tables.length < 1 || tables.length > operation.maxTables) {
        return { healthy: false, matched: matches2.length, detail: `expected 1-${operation.maxTables} tables, found ${matches2.length}` };
      }
      const headers = [];
      const dataRows = [];
      for (const table of tables) {
        const rows = [...table.querySelectorAll(operation.rowSelector)];
        const headerMatches = rows.filter((row) => normalize2(row.cells[0]?.textContent ?? null) === operation.headerText);
        if (headerMatches.length < 1 || headerMatches.length > 12) return { healthy: false, matched: headerMatches.length, detail: `expected 1-12 ${operation.headerText} headers per table` };
        const header = headerMatches[0];
        const columnCount = header.cells.length;
        if (columnCount < 2 || columnCount > 12) return { healthy: false, matched: columnCount, detail: "table header must contain 2-12 columns" };
        if (headerMatches.some((candidate) => candidate.cells.length !== columnCount)) {
          return { healthy: false, matched: headerMatches.length, detail: "repeated table headers must have the same column count" };
        }
        const headerSet = new Set(headerMatches);
        const rowsForTable = rows.filter((row) => !headerSet.has(row) && row.cells.length === columnCount);
        if (rowsForTable.length === 0) return { healthy: false, matched: 0, detail: "table has no bounded public data rows" };
        headers.push(...headerMatches);
        dataRows.push(...rowsForTable);
      }
      if (dataRows.length > operation.maxRows) return { healthy: false, matched: dataRows.length, detail: `public row bound exceeded (${dataRows.length}/${operation.maxRows})` };
      return { healthy: true, matched: dataRows.length, detail: `${dataRows.length} public rows searchable across ${tables.length} tables`, tables, headers, dataRows };
    } catch {
      return { healthy: false, matched: 0, detail: "public table inspection failed" };
    }
  }

  // src/core/engine.ts
  var MAX_MATCHES = 100;
  var SENSITIVE_AUTOCOMPLETE = /(?:current-password|new-password|one-time-code|cc-|transaction-|webauthn)/i;
  var SENSITIVE_FIELD_HINT = /(?:^|[-_.])(?:password|passwd|passcode|pin|otp|one[-_.]?time|verification[-_.]?code|auth[-_.]?code|security[-_.]?code|secret|token|cvv|cvc|card[-_.]?number|credit[-_.]?card|routing[-_.]?number|bank[-_.]?account|account[-_.]?number|social[-_.]?security|ssn|tax[-_.]?id|passport)(?:$|[-_.])/i;
  function installTrustedUiStyles(document2) {
    if (document2.querySelector("style[data-patch-the-web-ui]")) return;
    const style = document2.createElement("style");
    style.dataset.patchTheWebUi = "true";
    style.textContent = `
    .patch-the-web-save-status {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      margin: 0 0 18px;
      padding: 8px 12px;
      border: 1px solid #b7ebd0;
      border-radius: 999px;
      color: #086647;
      background: #effcf6;
      font: 600 13px/1.2 ui-sans-serif, system-ui, sans-serif;
    }
    .patch-the-web-save-status::before { content: "\u2713"; }
    .patch-the-web-field-error {
      margin: 7px 0 0;
      color: #b42318;
      font: 600 14px/1.35 ui-sans-serif, system-ui, sans-serif;
    }
    [aria-invalid="true"] {
      border-color: #d92d20 !important;
      box-shadow: 0 0 0 3px rgba(217, 45, 32, .12) !important;
    }
    .patch-the-web-navigator {
      margin: 0 0 24px;
      padding: 22px;
      border: 1px solid #b9e6d1;
      border-radius: 18px;
      color: #17352a;
      background: linear-gradient(145deg, #f2fcf7, #ffffff);
      box-shadow: 0 14px 36px rgba(22, 94, 67, .09);
      font-family: ui-sans-serif, system-ui, sans-serif;
    }
    .patch-the-web-navigator__head { display: flex; align-items: start; gap: 14px; margin-bottom: 18px; }
    .patch-the-web-navigator__mark {
      display: grid; place-items: center; width: 38px; height: 38px; flex: 0 0 auto;
      border-radius: 12px; color: #fff; background: #0b9569; font-weight: 850;
    }
    .patch-the-web-navigator h2 { margin: 0 0 4px; color: #143126; font-size: 20px; line-height: 1.2; }
    .patch-the-web-navigator p { margin: 0; color: #5f746b; font-size: 13px; line-height: 1.5; }
    .patch-the-web-navigator__controls { display: grid; grid-template-columns: minmax(210px, 1.4fr) repeat(3, minmax(130px, 1fr)); gap: 10px; }
    .patch-the-web-navigator label { display: grid; gap: 6px; color: #355649; font-size: 11px; font-weight: 800; }
    .patch-the-web-navigator input, .patch-the-web-navigator select {
      width: 100%; min-height: 42px; padding: 9px 11px; border: 1px solid #bed4ca; border-radius: 10px;
      color: #19362b; background: #fff; font: 500 13px/1.25 ui-sans-serif, system-ui, sans-serif;
    }
    .patch-the-web-navigator input:focus, .patch-the-web-navigator select:focus {
      outline: 3px solid rgba(11, 149, 105, .18); outline-offset: 1px; border-color: #0b9569;
    }
    .patch-the-web-navigator__receipt { display: flex; align-items: center; gap: 10px; margin-top: 15px; padding-top: 14px; border-top: 1px solid #dcece4; }
    .patch-the-web-navigator__status { color: #136b4d !important; font-weight: 800; }
    .patch-the-web-navigator__privacy { margin-left: auto !important; font-size: 10px !important; }
    .patch-the-web-navigator__clear {
      min-height: 34px; padding: 7px 10px; border: 1px solid #bad5c8; border-radius: 9px;
      color: #176248; background: #fff; font: 800 11px/1 ui-sans-serif, system-ui, sans-serif; cursor: pointer;
    }
    .patch-the-web-navigator__clear:focus-visible { outline: 3px solid rgba(11, 149, 105, .18); outline-offset: 2px; }
    .patch-the-web-table-search {
      margin: 0 0 22px; padding: 20px; border: 1px solid #b9e6d1; border-radius: 16px;
      color: #17352a; background: linear-gradient(145deg, #f2fcf7, #fff);
      box-shadow: 0 12px 30px rgba(22,94,67,.08); font-family: ui-sans-serif, system-ui, sans-serif;
    }
    .patch-the-web-table-search h2 { margin: 0 0 4px; color: #143126; font-size: 20px; line-height: 1.2; }
    .patch-the-web-table-search p { margin: 0; color: #5f746b; font-size: 13px; line-height: 1.5; }
    .patch-the-web-table-search label { display: grid; gap: 7px; margin-top: 15px; color: #355649; font-size: 11px; font-weight: 800; }
    .patch-the-web-table-search input { width: 100%; min-height: 43px; padding: 9px 11px; border: 1px solid #bed4ca; border-radius: 10px; color: #19362b; background: #fff; font: 500 14px/1.25 ui-sans-serif, system-ui, sans-serif; }
    .patch-the-web-table-search input:focus { outline: 3px solid rgba(11,149,105,.18); outline-offset: 1px; border-color: #0b9569; }
    .patch-the-web-table-search__receipt { display: flex; gap: 12px; align-items: center; margin-top: 13px; padding-top: 12px; border-top: 1px solid #dcece4; }
    .patch-the-web-table-search__status { color: #136b4d !important; font-weight: 800; }
    .patch-the-web-table-search__privacy { margin-left: auto !important; font-size: 10px !important; }
    .patch-the-web-compare {
      margin: -8px 0 26px;
      padding: 18px 20px;
      border: 1px solid #245d4a;
      border-radius: 18px;
      color: #fff;
      background: linear-gradient(135deg, #123a2d, #1d5a45);
      box-shadow: 0 16px 34px rgba(20, 68, 51, .16);
      font-family: ui-sans-serif, system-ui, sans-serif;
    }
    .patch-the-web-compare__bar { display: flex; align-items: center; gap: 16px; }
    .patch-the-web-compare__mark {
      display: grid; place-items: center; width: 38px; height: 38px; flex: 0 0 auto;
      border: 1px solid rgba(255,255,255,.2); border-radius: 12px; color: #102f25; background: #70dfb2; font-weight: 900;
    }
    .patch-the-web-compare__copy { min-width: 180px; }
    .patch-the-web-compare h2, .patch-the-web-compare h3 { margin: 0 0 3px; color: #fff; line-height: 1.2; }
    .patch-the-web-compare h2 { font-size: 17px; }
    .patch-the-web-compare h3 { font-size: 20px; }
    .patch-the-web-compare p { margin: 0; color: #c8ded5; font-size: 11px; line-height: 1.45; }
    .patch-the-web-compare__selection { display: flex; flex: 1; align-items: center; justify-content: flex-end; gap: 7px; flex-wrap: wrap; }
    .patch-the-web-compare__chip { padding: 6px 9px; border: 1px solid rgba(255,255,255,.18); border-radius: 999px; color: #eaf8f2; background: rgba(255,255,255,.08); font-size: 10px; font-weight: 750; }
    .patch-the-web-compare__actions { display: flex; gap: 7px; }
    .patch-the-web-compare__action, .patch-the-web-compare__close {
      min-height: 36px; padding: 8px 11px; border: 1px solid rgba(255,255,255,.24); border-radius: 9px;
      color: #12382c; background: #72e0b2; font: 800 11px/1 ui-sans-serif, system-ui, sans-serif; cursor: pointer;
    }
    .patch-the-web-compare__action.secondary, .patch-the-web-compare__close { color: #e9f7f1; background: transparent; }
    .patch-the-web-compare__action:disabled { color: #8bb5a5; background: #2b604d; cursor: not-allowed; }
    .patch-the-web-compare__action:focus-visible, .patch-the-web-compare__close:focus-visible, .patch-the-web-compare__select:focus-visible {
      outline: 3px solid rgba(112, 223, 178, .3); outline-offset: 2px;
    }
    .patch-the-web-compare__select {
      align-self: flex-start; margin: 14px 0 0; padding: 7px 10px; border: 1px solid #b9d4c8; border-radius: 9px;
      color: #176248; background: #f5fbf8; font: 800 10px/1 ui-sans-serif, system-ui, sans-serif; cursor: pointer;
    }
    .patch-the-web-compare__select[aria-pressed="true"] { border-color: #167e59; color: #fff; background: #167e59; }
    .patch-the-web-compare__select:disabled { opacity: .48; cursor: not-allowed; }
    [data-patch-the-web-compared] { box-shadow: 0 0 0 3px rgba(22, 126, 89, .14), 0 12px 30px rgba(29, 77, 58, .07) !important; }
    .patch-the-web-compare__result { margin-top: 18px; padding-top: 18px; border-top: 1px solid rgba(255,255,255,.18); }
    .patch-the-web-compare__result-head { display: flex; align-items: start; justify-content: space-between; gap: 16px; margin-bottom: 13px; }
    .patch-the-web-compare__table-wrap { overflow-x: auto; border: 1px solid rgba(255,255,255,.15); border-radius: 12px; background: #fff; }
    .patch-the-web-compare__table-wrap:focus-visible { outline: 3px solid #79e5b7; outline-offset: 3px; }
    .patch-the-web-compare table { width: 100%; min-width: 560px; border-collapse: collapse; color: #18372b; background: #fff; font-size: 11px; }
    .patch-the-web-compare th, .patch-the-web-compare td { padding: 11px 13px; border-bottom: 1px solid #e1ebe6; text-align: left; vertical-align: top; }
    .patch-the-web-compare thead th { color: #10392b; background: #eef8f3; font-size: 11px; }
    .patch-the-web-compare tbody th { width: 18%; color: #5c7168; background: #f8fbfa; font-size: 10px; text-transform: uppercase; letter-spacing: .05em; }
    .patch-the-web-compare tr:last-child th, .patch-the-web-compare tr:last-child td { border-bottom: 0; }
    .patch-the-web-compare__status { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
    @media (max-width: 760px) {
      .patch-the-web-navigator { padding: 18px; border-radius: 16px; }
      .patch-the-web-navigator__controls { grid-template-columns: 1fr; }
      .patch-the-web-navigator__receipt { align-items: flex-start; flex-wrap: wrap; }
      .patch-the-web-navigator__privacy { width: 100%; margin-left: 0 !important; }
      .patch-the-web-compare { margin-top: -6px; padding: 16px; }
      .patch-the-web-compare__bar { align-items: flex-start; flex-wrap: wrap; }
      .patch-the-web-compare__copy { flex: 1; }
      .patch-the-web-compare__selection { width: 100%; justify-content: flex-start; order: 3; }
      .patch-the-web-compare__actions { width: 100%; order: 4; }
      .patch-the-web-compare__action { flex: 1; }
      .patch-the-web-compare__result-head { flex-direction: column; }
    }
  `;
    document2.head.append(style);
  }
  function selected(document2, selector) {
    return [...document2.querySelectorAll(selector)].slice(0, MAX_MATCHES);
  }
  function isEligibleField(element) {
    if (!["INPUT", "SELECT", "TEXTAREA"].includes(element.tagName)) return false;
    if (element.tagName === "INPUT" && ["password", "file", "hidden", "submit", "button", "reset", "image"].includes(element.type)) return false;
    if (SENSITIVE_AUTOCOMPLETE.test(element.getAttribute("autocomplete") || "")) return false;
    if ([element.getAttribute("name") || "", element.getAttribute("id") || ""].some((value) => SENSITIVE_FIELD_HINT.test(value))) return false;
    return !element.disabled;
  }
  function fieldKeys(elements) {
    const bases = elements.map((element, index) => element.name || element.id || `field-${index}`);
    const counts = /* @__PURE__ */ new Map();
    bases.forEach((base) => counts.set(base, (counts.get(base) ?? 0) + 1));
    return bases.map((base, index) => (counts.get(base) ?? 0) > 1 ? `${base}:${index}` : base);
  }
  function readField(element) {
    if (element.tagName === "INPUT" && ["checkbox", "radio"].includes(element.type)) return element.checked;
    return element.value;
  }
  function writeField(element, value) {
    if (element.tagName === "INPUT" && ["checkbox", "radio"].includes(element.type)) {
      if (typeof value === "boolean") element.checked = value;
    } else if (typeof value === "string") {
      element.value = value;
    }
  }
  function viewportMatches(operation, window2) {
    if (!operation.when) return true;
    const width = window2.innerWidth;
    return (operation.when.minWidth === void 0 || width >= operation.when.minWidth) && (operation.when.maxWidth === void 0 || width <= operation.when.maxWidth);
  }
  function setupPersistence(patch, operation, context, form) {
    const { document: document2, storage } = context;
    const fields = operation.include.flatMap((selector) => selected(form.ownerDocument, `${operation.selector} ${selector}`)).filter(isEligibleField);
    const uniqueFields = [...new Set(fields)].slice(0, 40);
    const uniqueFieldKeys = fieldKeys(uniqueFields);
    const storageKey = `patch-the-web:${patch.id}:${operation.key}`;
    const status = document2.createElement("p");
    status.className = "patch-the-web-save-status";
    status.dataset.patchTheWebOwned = "true";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    status.textContent = operation.statusText;
    form.prepend(status);
    let restored = false;
    try {
      const raw = storage.getItem(storageKey);
      if (raw) {
        const stored = JSON.parse(raw);
        const savedAt = typeof stored.savedAt === "number" ? stored.savedAt : 0;
        const expired = Date.now() - savedAt > operation.ttlMinutes * 6e4;
        const values = stored.values && typeof stored.values === "object" && !Array.isArray(stored.values) ? stored.values : null;
        if (expired || !values) {
          storage.removeItem(storageKey);
          status.textContent = `Previous draft expired \xB7 ${operation.statusText}`;
        } else {
          uniqueFields.forEach((field, index) => writeField(field, values[uniqueFieldKeys[index]]));
          status.textContent = `Draft restored \xB7 ${operation.statusText}`;
          restored = true;
        }
      }
    } catch {
      status.textContent = "Local draft storage is unavailable";
    }
    const save = () => {
      const snapshot = {};
      uniqueFields.forEach((field, index) => {
        snapshot[uniqueFieldKeys[index]] = readField(field);
      });
      try {
        storage.setItem(storageKey, JSON.stringify({ savedAt: Date.now(), values: snapshot }));
        status.textContent = operation.statusText;
        status.dataset.state = "saved";
      } catch {
        status.textContent = "Could not save this draft on this device";
        status.dataset.state = "error";
      }
    };
    form.addEventListener("input", save);
    form.addEventListener("change", save);
    form.addEventListener("reset", () => storage.removeItem(storageKey));
    return { matched: uniqueFields.length, detail: restored ? "draft restored" : "draft storage ready" };
  }
  function ruleFailure(value, rule) {
    if (rule.kind === "required") return value.trim().length === 0;
    if (rule.kind === "email") return value.length > 0 && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    if (rule.kind === "minLength") return value.length > 0 && value.length < Number(rule.value);
    if (rule.kind === "pattern") {
      try {
        return value.length > 0 && !new RegExp(String(rule.value)).test(value);
      } catch {
        return true;
      }
    }
    return false;
  }
  function setupValidation(operation, context, form) {
    const { document: document2 } = context;
    const pairs = operation.fields.flatMap(
      (field) => selected(document2, field.selector).filter((element) => isEligibleField(element)).map((element) => ({ element, rules: field.rules }))
    );
    const validate = (element, rules) => {
      const existingId = `patch-the-web-error-${operation.id}-${element.id || element.name || "field"}`.replace(/[^a-z0-9_-]/gi, "-");
      document2.getElementById(existingId)?.remove();
      element.removeAttribute("aria-invalid");
      const originalDescription = (element.getAttribute("aria-describedby") || "").split(/\s+/).filter((id) => id && id !== existingId);
      const failed = rules.find((rule) => ruleFailure(element.value, rule));
      if (!failed) {
        if (originalDescription.length > 0) element.setAttribute("aria-describedby", originalDescription.join(" "));
        else element.removeAttribute("aria-describedby");
        return true;
      }
      const error = document2.createElement("p");
      error.id = existingId;
      error.className = "patch-the-web-field-error";
      error.dataset.patchTheWebOwned = "true";
      error.setAttribute("role", "alert");
      error.textContent = failed.message;
      element.setAttribute("aria-invalid", "true");
      element.setAttribute("aria-describedby", [...originalDescription, existingId].join(" "));
      element.insertAdjacentElement("afterend", error);
      return false;
    };
    pairs.forEach(({ element, rules }) => {
      element.addEventListener("blur", () => validate(element, rules));
      element.addEventListener("input", () => {
        if (element.getAttribute("aria-invalid") === "true") validate(element, rules);
      });
      element.addEventListener("change", () => {
        if (element.getAttribute("aria-invalid") === "true") validate(element, rules);
      });
    });
    form.addEventListener("submit", (event) => {
      const invalid = pairs.filter(({ element, rules }) => !validate(element, rules));
      if (invalid.length > 0) {
        event.preventDefault();
        invalid[0].element.focus();
      }
    });
    return pairs.length;
  }
  function splitAttributeTokens(value) {
    return (value ?? "").slice(0, 4096).toLowerCase().split(/[\s,|]+/).filter(Boolean).slice(0, 100);
  }
  function setupCollectionFilter(patch, operation, context, container) {
    const { document: document2, storage } = context;
    const items = [...container.querySelectorAll(operation.items)].slice(0, MAX_MATCHES);
    if (items.length === 0) return { matched: 0, detail: "no collection items found" };
    const panel = document2.createElement("section");
    panel.className = "patch-the-web-navigator";
    panel.dataset.patchTheWebOwned = "true";
    panel.setAttribute("aria-label", operation.title);
    const head = document2.createElement("div");
    head.className = "patch-the-web-navigator__head";
    const mark = document2.createElement("span");
    mark.className = "patch-the-web-navigator__mark";
    mark.setAttribute("aria-hidden", "true");
    mark.textContent = "\u2315";
    const copy = document2.createElement("div");
    const title = document2.createElement("h2");
    title.textContent = operation.title;
    const description = document2.createElement("p");
    description.textContent = operation.description;
    copy.append(title, description);
    head.append(mark, copy);
    const controls = document2.createElement("div");
    controls.className = "patch-the-web-navigator__controls";
    const searchId = `patch-the-web-search-${operation.id}`;
    const searchLabel = document2.createElement("label");
    searchLabel.htmlFor = searchId;
    searchLabel.append(document2.createTextNode(operation.search.label));
    const search = document2.createElement("input");
    search.id = searchId;
    search.type = "search";
    search.autocomplete = "off";
    search.placeholder = operation.search.placeholder ?? "";
    search.setAttribute("aria-keyshortcuts", "/");
    searchLabel.append(search);
    controls.append(searchLabel);
    const selects = operation.filters.map((filter) => {
      const id = `patch-the-web-filter-${operation.id}-${filter.id}`;
      const label = document2.createElement("label");
      label.htmlFor = id;
      label.append(document2.createTextNode(filter.label));
      const select = document2.createElement("select");
      select.id = id;
      const any = document2.createElement("option");
      any.value = "";
      any.textContent = `Any ${filter.label.toLowerCase()}`;
      select.append(any);
      filter.options.forEach((option) => {
        const element = document2.createElement("option");
        element.value = option.value;
        element.textContent = option.label;
        select.append(element);
      });
      label.append(select);
      controls.append(label);
      return { filter, select };
    });
    const receipt = document2.createElement("div");
    receipt.className = "patch-the-web-navigator__receipt";
    const status = document2.createElement("p");
    status.className = "patch-the-web-navigator__status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    const clear = document2.createElement("button");
    clear.type = "button";
    clear.className = "patch-the-web-navigator__clear";
    clear.textContent = "Clear filters";
    const privacy = document2.createElement("p");
    privacy.className = "patch-the-web-navigator__privacy";
    privacy.textContent = operation.persist ? `Preferences stay on this device for ${Math.round(operation.persist.ttlMinutes / 60)} hours` : "Filtering stays on this page";
    receipt.append(status, clear, privacy);
    panel.append(head, controls, receipt);
    container.prepend(panel);
    const storageKey = operation.persist ? `patch-the-web:${patch.id}:${operation.persist.key}` : null;
    const readState = () => ({
      search: search.value,
      filters: Object.fromEntries(selects.map(({ filter, select }) => [filter.id, select.value]))
    });
    const saveState = () => {
      if (!storageKey) return;
      try {
        storage.setItem(storageKey, JSON.stringify({ savedAt: Date.now(), ...readState() }));
      } catch {
      }
    };
    const apply = (persist = true) => {
      const query = search.value.trim().toLowerCase();
      let visible = 0;
      items.forEach((item) => {
        const searchable = operation.search.attributes.map((attribute) => item.getAttribute(attribute) ?? "").join(" ").toLowerCase();
        const matchesSearch = query.length === 0 || query.split(/\s+/).every((term) => searchable.includes(term));
        const matchesFilters = selects.every(({ filter, select }) => {
          if (!select.value) return true;
          return splitAttributeTokens(item.getAttribute(filter.attribute)).includes(select.value.toLowerCase());
        });
        const show = matchesSearch && matchesFilters;
        item.hidden = !show;
        item.toggleAttribute("data-patch-the-web-filtered", !show);
        if (show) visible += 1;
      });
      status.textContent = `${visible} of ${items.length} services match`;
      if (persist) saveState();
    };
    if (storageKey && operation.persist) {
      try {
        const raw = storage.getItem(storageKey);
        if (raw) {
          const saved = JSON.parse(raw);
          const savedAt = typeof saved.savedAt === "number" ? saved.savedAt : 0;
          if (Date.now() - savedAt <= operation.persist.ttlMinutes * 6e4) {
            if (typeof saved.search === "string") search.value = saved.search;
            if (saved.filters && typeof saved.filters === "object" && !Array.isArray(saved.filters)) {
              const storedFilters = saved.filters;
              selects.forEach(({ filter, select }) => {
                if (typeof storedFilters[filter.id] === "string") select.value = String(storedFilters[filter.id]);
              });
            }
          } else storage.removeItem(storageKey);
        }
      } catch {
      }
    }
    search.addEventListener("input", () => apply());
    selects.forEach(({ select }) => select.addEventListener("change", () => apply()));
    clear.addEventListener("click", () => {
      search.value = "";
      selects.forEach(({ select }) => {
        select.value = "";
      });
      apply(false);
      if (storageKey) {
        try {
          storage.removeItem(storageKey);
        } catch {
        }
      }
      search.focus();
    });
    document2.addEventListener("keydown", (event) => {
      const keyboardEvent = event;
      const active = document2.activeElement;
      const typing = active?.tagName === "INPUT" || active?.tagName === "TEXTAREA" || active?.tagName === "SELECT" || active?.isContentEditable;
      if (keyboardEvent.key === "/" && !typing) {
        keyboardEvent.preventDefault();
        search.focus();
      }
      if (keyboardEvent.key === "Escape" && document2.activeElement === search && search.value) {
        search.value = "";
        apply();
      }
    });
    apply(false);
    return { matched: items.length, detail: `${items.length} items filterable` };
  }
  function setupCollectionCompare(operation, context, container) {
    const { document: document2 } = context;
    const items = [...container.querySelectorAll(operation.items)].slice(0, MAX_MATCHES);
    const titledItems = items.map((item) => ({
      item,
      title: item.getAttribute(operation.itemTitleAttribute)?.trim().slice(0, 120) ?? ""
    }));
    const titles = titledItems.map(({ title: title2 }) => title2);
    if (items.length < 2 || titles.some((title2) => !title2) || new Set(titles).size !== titles.length) {
      return { matched: items.length, applied: false, detail: "comparison requires unique declared item titles" };
    }
    const panel = document2.createElement("section");
    panel.className = "patch-the-web-compare";
    panel.dataset.patchTheWebOwned = "true";
    panel.setAttribute("aria-label", operation.title);
    const bar = document2.createElement("div");
    bar.className = "patch-the-web-compare__bar";
    const mark = document2.createElement("span");
    mark.className = "patch-the-web-compare__mark";
    mark.setAttribute("aria-hidden", "true");
    mark.textContent = "\u21C4";
    const copy = document2.createElement("div");
    copy.className = "patch-the-web-compare__copy";
    const title = document2.createElement("h2");
    title.textContent = operation.title;
    const description = document2.createElement("p");
    description.textContent = operation.description;
    copy.append(title, description);
    const selection = document2.createElement("div");
    selection.className = "patch-the-web-compare__selection";
    const actions = document2.createElement("div");
    actions.className = "patch-the-web-compare__actions";
    const clear = document2.createElement("button");
    clear.type = "button";
    clear.className = "patch-the-web-compare__action secondary";
    clear.textContent = "Clear";
    const compare = document2.createElement("button");
    compare.type = "button";
    compare.className = "patch-the-web-compare__action";
    compare.textContent = "Compare selected";
    compare.disabled = true;
    actions.append(clear, compare);
    bar.append(mark, copy, selection, actions);
    const liveStatus = document2.createElement("p");
    liveStatus.className = "patch-the-web-compare__status";
    liveStatus.setAttribute("role", "status");
    liveStatus.setAttribute("aria-live", "polite");
    const result = document2.createElement("section");
    result.className = "patch-the-web-compare__result";
    result.hidden = true;
    const resultHead = document2.createElement("div");
    resultHead.className = "patch-the-web-compare__result-head";
    const resultCopy = document2.createElement("div");
    const resultTitle = document2.createElement("h3");
    resultTitle.id = `patch-the-web-compare-title-${operation.id}`;
    resultTitle.tabIndex = -1;
    resultTitle.textContent = "Service comparison";
    const resultDescription = document2.createElement("p");
    resultDescription.id = `patch-the-web-compare-description-${operation.id}`;
    resultDescription.textContent = "A private side-by-side view built only from the declared directory fields.";
    result.setAttribute("aria-labelledby", resultTitle.id);
    result.setAttribute("aria-describedby", resultDescription.id);
    resultCopy.append(resultTitle, resultDescription);
    const close = document2.createElement("button");
    close.type = "button";
    close.className = "patch-the-web-compare__close";
    close.textContent = "Close comparison";
    resultHead.append(resultCopy, close);
    const tableWrap = document2.createElement("div");
    tableWrap.className = "patch-the-web-compare__table-wrap";
    tableWrap.tabIndex = 0;
    tableWrap.setAttribute("role", "region");
    tableWrap.setAttribute("aria-label", "Scrollable service comparison");
    result.append(resultHead, tableWrap);
    panel.append(bar, liveStatus, result);
    const navigator = [...container.children].find((element) => element.classList.contains("patch-the-web-navigator"));
    if (navigator) navigator.insertAdjacentElement("afterend", panel);
    else container.prepend(panel);
    const selectedItems = /* @__PURE__ */ new Set();
    const buttons = titledItems.map(({ item, title: itemTitle }) => {
      const button = document2.createElement("button");
      button.type = "button";
      button.className = "patch-the-web-compare__select";
      button.dataset.patchTheWebOwned = "true";
      button.setAttribute("aria-pressed", "false");
      button.setAttribute("aria-label", `Add ${itemTitle} to comparison`);
      button.textContent = "Compare";
      const link = item.querySelector("a[href]");
      if (link) link.insertAdjacentElement("beforebegin", button);
      else item.append(button);
      return { item, itemTitle, button };
    });
    const displayValue = (item, field) => {
      const tokens = new Set(splitAttributeTokens(item.getAttribute(field.attribute)));
      const labels = field.values.filter((option) => tokens.has(option.value.toLowerCase())).map((option) => option.label);
      return labels.length > 0 ? labels.join(", ") : "Not listed";
    };
    const renderSelection = () => {
      selection.replaceChildren(...buttons.filter(({ item }) => selectedItems.has(item)).map(({ itemTitle }) => {
        const chip = document2.createElement("span");
        chip.className = "patch-the-web-compare__chip";
        chip.textContent = itemTitle;
        return chip;
      }));
      const count = selectedItems.size;
      compare.disabled = count < 2;
      clear.disabled = count === 0;
      buttons.forEach(({ item, itemTitle, button }) => {
        const pressed = selectedItems.has(item);
        button.setAttribute("aria-pressed", String(pressed));
        button.setAttribute("aria-label", `${pressed ? "Remove" : "Add"} ${itemTitle} ${pressed ? "from" : "to"} comparison`);
        button.textContent = pressed ? "Selected" : "Compare";
        button.disabled = !pressed && count >= operation.maxItems;
        item.toggleAttribute("data-patch-the-web-compared", pressed);
      });
      liveStatus.textContent = count === 0 ? `Choose 2 to ${operation.maxItems} items to compare.` : count === 1 ? "1 item selected. Choose at least one more." : `${count} items selected and ready to compare.`;
      if (count < 2) result.hidden = true;
    };
    buttons.forEach(({ item, button }) => button.addEventListener("click", () => {
      if (selectedItems.has(item)) selectedItems.delete(item);
      else if (selectedItems.size < operation.maxItems) selectedItems.add(item);
      renderSelection();
    }));
    compare.addEventListener("click", () => {
      const chosen = buttons.filter(({ item }) => selectedItems.has(item));
      if (chosen.length < 2) return;
      const table = document2.createElement("table");
      table.setAttribute("aria-labelledby", resultTitle.id);
      table.setAttribute("aria-describedby", resultDescription.id);
      const thead = document2.createElement("thead");
      const headRow = document2.createElement("tr");
      const criteriaHead = document2.createElement("th");
      criteriaHead.scope = "col";
      criteriaHead.textContent = "What matters";
      headRow.append(criteriaHead, ...chosen.map(({ itemTitle }) => {
        const cell = document2.createElement("th");
        cell.scope = "col";
        cell.textContent = itemTitle;
        return cell;
      }));
      thead.append(headRow);
      const tbody = document2.createElement("tbody");
      operation.fields.forEach((field) => {
        const row = document2.createElement("tr");
        const label = document2.createElement("th");
        label.scope = "row";
        label.textContent = field.label;
        row.append(label, ...chosen.map(({ item }) => {
          const cell = document2.createElement("td");
          cell.textContent = displayValue(item, field);
          return cell;
        }));
        tbody.append(row);
      });
      table.append(thead, tbody);
      tableWrap.replaceChildren(table);
      result.hidden = false;
      liveStatus.textContent = `Comparison opened for ${chosen.length} items.`;
      resultTitle.focus();
      if (typeof result.scrollIntoView === "function") result.scrollIntoView({ block: "nearest" });
    });
    clear.addEventListener("click", () => {
      selectedItems.clear();
      result.hidden = true;
      renderSelection();
      (buttons.find(({ item }) => !item.hidden)?.button ?? compare).focus();
    });
    close.addEventListener("click", () => {
      result.hidden = true;
      compare.focus();
    });
    renderSelection();
    return { matched: items.length, applied: true, detail: `${items.length} items safely comparable` };
  }
  function setupPublicTableSearch(operation, context) {
    const inspection = inspectPublicTableSearch(operation, context.document);
    if (!inspection.healthy || !inspection.tables || !inspection.headers || !inspection.dataRows) return inspection;
    const { document: document2 } = context;
    const panel = document2.createElement("section");
    panel.className = "patch-the-web-table-search";
    panel.dataset.patchTheWebOwned = "true";
    const title = document2.createElement("h2");
    title.textContent = operation.title;
    const description = document2.createElement("p");
    description.textContent = operation.description;
    const label = document2.createElement("label");
    label.textContent = operation.searchLabel;
    const input = document2.createElement("input");
    input.type = "search";
    input.placeholder = operation.placeholder ?? "";
    input.autocomplete = "off";
    const receipt = document2.createElement("div");
    receipt.className = "patch-the-web-table-search__receipt";
    const status = document2.createElement("p");
    status.className = "patch-the-web-table-search__status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    const privacy = document2.createElement("p");
    privacy.className = "patch-the-web-table-search__privacy";
    privacy.textContent = "Search stays on this page";
    label.append(input);
    receipt.append(status, privacy);
    panel.append(title, description, label, receipt);
    inspection.tables[0].before(panel);
    inspection.tables.forEach((table, index) => table.setAttribute("aria-label", `${operation.tableLabel} ${index + 1} of ${inspection.tables.length}`));
    inspection.headers.forEach((row) => [...row.cells].forEach((cell) => {
      cell.setAttribute("role", "columnheader");
      cell.setAttribute("scope", "col");
    }));
    const searchable = inspection.dataRows.map((row) => ({ row, text: (row.textContent ?? "").replace(/\s+/g, " ").trim().toLocaleLowerCase() }));
    const update = () => {
      const query = input.value.replace(/\s+/g, " ").trim().toLocaleLowerCase();
      let visible = 0;
      searchable.forEach(({ row, text: text2 }) => {
        const match = query.length === 0 || text2.includes(query);
        row.hidden = !match;
        row.style.setProperty("display", match ? "" : "none", match ? "" : "important");
        row.toggleAttribute("aria-hidden", !match);
        row.dataset.patchTheWebTableSearchMatch = String(match);
        if (match) visible += 1;
      });
      status.textContent = query ? `${visible} of ${searchable.length} rows match` : `${searchable.length} public rows available`;
    };
    input.addEventListener("input", update);
    input.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && input.value) {
        input.value = "";
        update();
      }
    });
    document2.addEventListener("keydown", (event) => {
      if (event.key === "/" && document2.activeElement !== input) {
        event.preventDefault();
        input.focus();
      }
    });
    update();
    return inspection;
  }
  function applyOperation(patch, operation, context) {
    const { document: document2, window: window2 } = context;
    try {
      if (operation.type === "style") {
        const elements = selected(document2, operation.selector);
        if (!viewportMatches(operation, window2)) return { id: operation.id, type: operation.type, matched: elements.length, applied: true, detail: "viewport rule inactive" };
        elements.forEach((element) => Object.entries(operation.styles).forEach(([property, value]) => element.style.setProperty(property, value)));
        return { id: operation.id, type: operation.type, matched: elements.length, applied: elements.length > 0 };
      }
      if (operation.type === "attributes") {
        const elements = selected(document2, operation.selector);
        elements.forEach((element) => Object.entries(operation.attributes).forEach(([name, value]) => element.setAttribute(name, value)));
        return { id: operation.id, type: operation.type, matched: elements.length, applied: elements.length > 0 };
      }
      if (operation.type === "hide") {
        const elements = selected(document2, operation.selector);
        elements.forEach((element) => {
          element.hidden = true;
          element.setAttribute("aria-hidden", "true");
        });
        return { id: operation.id, type: operation.type, matched: elements.length, applied: elements.length > 0 };
      }
      if (operation.type === "move") {
        const elements = selected(document2, operation.selector);
        const targets = selected(document2, operation.target);
        if (targets.length !== 1 || elements.length === 0) return { id: operation.id, type: operation.type, matched: elements.length, applied: false, detail: `expected one target, found ${targets.length}` };
        const target = targets[0];
        elements.forEach((element) => {
          if (operation.position === "before") target.before(element);
          if (operation.position === "after") target.after(element);
          if (operation.position === "prepend") target.prepend(element);
          if (operation.position === "append") target.append(element);
        });
        return { id: operation.id, type: operation.type, matched: elements.length, applied: true };
      }
      if (operation.type === "persistForm") {
        const forms = selected(document2, operation.selector).filter((element) => element.tagName === "FORM");
        if (forms.length !== 1) return { id: operation.id, type: operation.type, matched: forms.length, applied: false, detail: "expected exactly one form" };
        const result = setupPersistence(patch, operation, context, forms[0]);
        return { id: operation.id, type: operation.type, matched: result.matched, applied: result.matched > 0, detail: result.detail };
      }
      if (operation.type === "validation") {
        const forms = selected(document2, operation.selector).filter((element) => element.tagName === "FORM");
        if (forms.length !== 1) return { id: operation.id, type: operation.type, matched: forms.length, applied: false, detail: "expected exactly one form" };
        const count = setupValidation(operation, context, forms[0]);
        return { id: operation.id, type: operation.type, matched: count, applied: count > 0 };
      }
      if (operation.type === "collectionFilter") {
        const containers2 = selected(document2, operation.selector);
        if (containers2.length !== 1) return { id: operation.id, type: operation.type, matched: containers2.length, applied: false, detail: "expected exactly one collection container" };
        const result = setupCollectionFilter(patch, operation, context, containers2[0]);
        return { id: operation.id, type: operation.type, matched: result.matched, applied: result.matched > 0, detail: result.detail };
      }
      if (operation.type === "collectionCompare") {
        const containers2 = selected(document2, operation.selector);
        if (containers2.length !== 1) return { id: operation.id, type: operation.type, matched: containers2.length, applied: false, detail: "expected exactly one collection container" };
        const result = setupCollectionCompare(operation, context, containers2[0]);
        return { id: operation.id, type: operation.type, matched: result.matched, applied: result.applied, detail: result.detail };
      }
      if (operation.type === "tableColumnFilter") {
        const inspection = inspectTableColumnFilter(operation, document2);
        if (!inspection.healthy || !inspection.table || !inspection.header || !inspection.matchingRows || !inspection.hiddenRows || !inspection.matrixRows || inspection.columnIndex === void 0) {
          return { id: operation.id, type: operation.type, matched: inspection.matched, applied: false, detail: inspection.detail };
        }
        inspection.table.setAttribute("aria-label", operation.tableLabel);
        inspection.table.dataset.patchTheWebTableFilter = "active";
        inspection.header.setAttribute("aria-label", operation.columnLabel);
        const columnIndex = inspection.columnIndex;
        inspection.hiddenRows.forEach((row) => {
          row.hidden = true;
          row.style.setProperty("display", "none", "important");
          row.setAttribute("aria-hidden", "true");
          row.dataset.patchTheWebTableRowHidden = "true";
        });
        inspection.matchingRows.forEach((row) => {
          row.dataset.patchTheWebTableRowMatch = "true";
          const cells = [...row.children].filter((cell) => cell.tagName === "TH" || cell.tagName === "TD");
          const marker = cells[columnIndex].querySelector(operation.markerSelector);
          marker?.setAttribute("role", "img");
          marker?.setAttribute("aria-hidden", "false");
          marker?.setAttribute("aria-label", operation.markerLabel);
          marker?.setAttribute("title", operation.markerLabel);
        });
        if (operation.collapseOtherColumns) {
          inspection.matrixRows.forEach((row) => {
            const cells = [...row.children].filter((cell) => cell.tagName === "TH" || cell.tagName === "TD");
            cells.forEach((cell, index) => {
              if (index === 0 || index === columnIndex) return;
              cell.hidden = true;
              cell.style.setProperty("display", "none", "important");
              cell.setAttribute("aria-hidden", "true");
              cell.dataset.patchTheWebTableColumnHidden = "true";
            });
          });
        }
        return { id: operation.id, type: operation.type, matched: inspection.matched, applied: true, detail: inspection.detail };
      }
      if (operation.type === "publicTableSearch") {
        const inspection = setupPublicTableSearch(operation, context);
        return { id: operation.id, type: operation.type, matched: inspection.matched, applied: inspection.healthy, detail: inspection.detail };
      }
      const containers = selected(document2, operation.container);
      if (containers.length !== 1) return { id: operation.id, type: operation.type, matched: containers.length, applied: false, detail: "expected exactly one navigation container" };
      const items = [...containers[0].querySelectorAll(operation.items)].slice(0, 50);
      items.forEach((item, index) => item.tabIndex = index === 0 ? 0 : -1);
      containers[0].addEventListener("keydown", (event) => {
        const keyboardEvent = event;
        const previousKey = operation.orientation === "horizontal" ? "ArrowLeft" : "ArrowUp";
        const nextKey = operation.orientation === "horizontal" ? "ArrowRight" : "ArrowDown";
        if (![previousKey, nextKey, "Home", "End"].includes(keyboardEvent.key)) return;
        const current = items.indexOf(document2.activeElement);
        if (current < 0) return;
        keyboardEvent.preventDefault();
        let next = keyboardEvent.key === "Home" ? 0 : keyboardEvent.key === "End" ? items.length - 1 : current + (keyboardEvent.key === nextKey ? 1 : -1);
        if (operation.wrap !== false) next = (next + items.length) % items.length;
        else next = Math.max(0, Math.min(items.length - 1, next));
        items.forEach((item, index) => item.tabIndex = index === next ? 0 : -1);
        items[next]?.focus();
      });
      return { id: operation.id, type: operation.type, matched: items.length, applied: items.length > 0 };
    } catch (error) {
      return { id: operation.id, type: operation.type, matched: 0, applied: false, detail: error instanceof Error ? error.message : "operation failed" };
    }
  }
  function applyPatch(patch, context = {}) {
    const documentRef = context.document ?? document;
    const windowRef = context.window ?? window;
    const storageRef = context.storage ?? windowRef.localStorage;
    const marker = `${patch.id}@${patch.version}`;
    installTrustedUiStyles(documentRef);
    const root = documentRef.documentElement;
    const appliedMarkers = new Set((root.dataset.patchTheWebApplied ?? "").split(/\s+/).filter(Boolean));
    if (appliedMarkers.has(marker)) {
      return { patchId: patch.id, version: patch.version, applied: true, operations: [], healthy: patch.operations.length, total: patch.operations.length, timestamp: Date.now() };
    }
    const operations = patch.operations.map((operation) => applyOperation(patch, operation, { document: documentRef, window: windowRef, storage: storageRef }));
    const healthy = operations.filter((operation) => operation.applied).length;
    appliedMarkers.add(marker);
    root.dataset.patchTheWebApplied = [...appliedMarkers].join(" ");
    root.classList.add("patch-the-web-active");
    return {
      patchId: patch.id,
      version: patch.version,
      applied: healthy === operations.length,
      operations,
      healthy,
      total: operations.length,
      timestamp: Date.now()
    };
  }

  // src/core/matcher.ts
  function hostMatches(pattern, host) {
    if (pattern.startsWith("*.")) {
      const suffix = pattern.slice(1);
      return host.endsWith(suffix) && host !== suffix.slice(1);
    }
    return pattern === host;
  }
  function pathMatches(pattern, pathname) {
    if (pattern.endsWith("*")) return pathname.startsWith(pattern.slice(0, -1));
    return pattern === pathname;
  }
  function patchMatchesUrl(patch, url) {
    return patch.match.hosts.some((host) => hostMatches(host, url.hostname)) && patch.match.paths.some((path) => pathMatches(path, url.pathname));
  }

  // src/core/validator.ts
  var CAPABILITIES = /* @__PURE__ */ new Set([
    "layout",
    "accessibility",
    "local-storage",
    "keyboard-navigation",
    "validation",
    "content-filter",
    "content-compare",
    "hide-elements",
    "reorganize"
  ]);
  var SAFE_STYLE_PROPERTIES = /* @__PURE__ */ new Set([
    "display",
    "position",
    "inset",
    "top",
    "right",
    "bottom",
    "left",
    "z-index",
    "width",
    "min-width",
    "max-width",
    "height",
    "min-height",
    "max-height",
    "margin",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "padding",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "gap",
    "row-gap",
    "column-gap",
    "grid-template-columns",
    "grid-template-rows",
    "grid-column",
    "grid-row",
    "flex-direction",
    "flex-wrap",
    "align-items",
    "align-content",
    "justify-content",
    "order",
    "overflow",
    "overflow-x",
    "overflow-y",
    "font-size",
    "font-weight",
    "line-height",
    "letter-spacing",
    "text-align",
    "color",
    "background-color",
    "border",
    "border-width",
    "border-style",
    "border-color",
    "border-radius",
    "box-shadow",
    "opacity",
    "visibility",
    "cursor",
    "outline",
    "outline-offset",
    "table-layout",
    "overflow-wrap",
    "word-break"
  ]);
  var SAFE_ATTRIBUTE = /^(aria-[a-z-]+|role|tabindex|autocomplete|inputmode|title)$/;
  var SAFE_ID = /^[a-z0-9][a-z0-9._-]{2,79}$/;
  var SAFE_VERSION = /^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/i;
  var SAFE_HOST = /^(localhost|127\.0\.0\.1|(?:\*\.)?[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+)$/i;
  var SAFE_PATH = /^\/[a-z0-9._~!$&'()+,;=:@%/-]*\*?$/i;
  var UNSAFE_VALUE = /(javascript\s*:|expression\s*\(|url\s*\(|@import|<\/?script|onerror\s*=|onload\s*=)/i;
  var UNSAFE_SELECTOR = /(^|[\s,>+~])(?:html|head|body|\*)(?:$|[\s,>+~.#[:])|:root\b|:(?:is|where|not|has)\([^)]*\*/i;
  var UNSAFE_PATTERN = /(\\[1-9]|\(\?[=!<]|\([^)]*[+*][^)]*\)[+*?{])/;
  var SAFE_DATA_ATTRIBUTE = /^data-[a-z0-9]+(?:-[a-z0-9]+)*$/;
  var SAFE_TOKEN = /^[a-z0-9][a-z0-9_-]{0,39}$/i;
  var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var text = (value, max) => typeof value === "string" && value.trim().length > 0 && value.length <= max;
  function checkSelector(selector, path, issues) {
    if (!text(selector, 240)) {
      issues.push({ path, message: "must be a non-empty selector under 240 characters" });
      return;
    }
    const value = selector;
    if (UNSAFE_SELECTOR.test(value)) {
      issues.push({ path, message: "may not target document-wide html, head, body, or universal selectors" });
    }
    if (typeof document !== "undefined") {
      try {
        document.createDocumentFragment().querySelector(value);
      } catch {
        issues.push({ path, message: "is not valid CSS selector syntax" });
      }
    }
  }
  function checkOperation(value, index, issues) {
    const base = `operations[${index}]`;
    if (!isRecord(value)) {
      issues.push({ path: base, message: "must be an object" });
      return;
    }
    if (!text(value.id, 80) || !SAFE_ID.test(String(value.id))) {
      issues.push({ path: `${base}.id`, message: "must use 3-80 lowercase letters, numbers, dots, dashes, or underscores" });
    }
    const type = value.type;
    const known = ["style", "attributes", "hide", "move", "persistForm", "validation", "keyboardNavigation", "collectionFilter", "collectionCompare", "tableColumnFilter", "publicTableSearch"];
    if (typeof type !== "string" || !known.includes(type)) {
      issues.push({ path: `${base}.type`, message: "is not an allowed transformation" });
      return;
    }
    if (["style", "attributes", "hide", "move", "persistForm", "validation", "collectionFilter", "collectionCompare", "tableColumnFilter", "publicTableSearch"].includes(type)) {
      checkSelector(value.selector, `${base}.selector`, issues);
    }
    if (type === "style") {
      if (!isRecord(value.styles) || Object.keys(value.styles).length === 0 || Object.keys(value.styles).length > 32) {
        issues.push({ path: `${base}.styles`, message: "must contain 1-32 style declarations" });
      } else {
        for (const [property, raw] of Object.entries(value.styles)) {
          if (!SAFE_STYLE_PROPERTIES.has(property)) {
            issues.push({ path: `${base}.styles.${property}`, message: "property is outside the layout allowlist" });
          }
          if (typeof raw !== "string" || raw.length > 160 || UNSAFE_VALUE.test(raw) || /[{};]/.test(raw)) {
            issues.push({ path: `${base}.styles.${property}`, message: "contains an unsafe or invalid CSS value" });
          }
        }
      }
      if (value.when !== void 0) {
        if (!isRecord(value.when)) {
          issues.push({ path: `${base}.when`, message: "must be a viewport constraint object" });
        } else {
          for (const key of ["minWidth", "maxWidth"]) {
            if (value.when[key] !== void 0 && (typeof value.when[key] !== "number" || value.when[key] < 240 || value.when[key] > 5e3)) {
              issues.push({ path: `${base}.when.${key}`, message: "must be between 240 and 5000" });
            }
          }
        }
      }
    }
    if (type === "attributes") {
      if (!isRecord(value.attributes) || Object.keys(value.attributes).length === 0 || Object.keys(value.attributes).length > 20) {
        issues.push({ path: `${base}.attributes`, message: "must contain 1-20 attributes" });
      } else {
        for (const [name, raw] of Object.entries(value.attributes)) {
          if (!SAFE_ATTRIBUTE.test(name)) {
            issues.push({ path: `${base}.attributes.${name}`, message: "only ARIA and safe interaction attributes are allowed" });
          }
          if (typeof raw !== "string" || raw.length > 240 || UNSAFE_VALUE.test(raw)) {
            issues.push({ path: `${base}.attributes.${name}`, message: "contains an unsafe value" });
          }
        }
      }
    }
    if (type === "move") {
      checkSelector(value.target, `${base}.target`, issues);
      if (!["before", "after", "prepend", "append"].includes(String(value.position))) {
        issues.push({ path: `${base}.position`, message: "must be before, after, prepend, or append" });
      }
    }
    if (type === "persistForm") {
      if (!text(value.key, 80) || !/^[a-z0-9._-]+$/i.test(String(value.key))) {
        issues.push({ path: `${base}.key`, message: "must be a stable storage key" });
      }
      if (!Array.isArray(value.include) || value.include.length === 0 || value.include.length > 12) {
        issues.push({ path: `${base}.include`, message: "must list 1-12 field selectors" });
      } else {
        value.include.forEach((selector, i) => checkSelector(selector, `${base}.include[${i}]`, issues));
      }
      if (!Number.isInteger(value.ttlMinutes) || Number(value.ttlMinutes) < 5 || Number(value.ttlMinutes) > 10080) {
        issues.push({ path: `${base}.ttlMinutes`, message: "must expire drafts between 5 minutes and 7 days" });
      }
      if (!text(value.statusText, 120)) {
        issues.push({ path: `${base}.statusText`, message: "must be concise visible status text" });
      }
    }
    if (type === "validation") {
      if (!Array.isArray(value.fields) || value.fields.length === 0 || value.fields.length > 30) {
        issues.push({ path: `${base}.fields`, message: "must define 1-30 fields" });
      } else {
        value.fields.forEach((field, fieldIndex) => {
          const fieldPath = `${base}.fields[${fieldIndex}]`;
          if (!isRecord(field)) {
            issues.push({ path: fieldPath, message: "must be an object" });
            return;
          }
          checkSelector(field.selector, `${fieldPath}.selector`, issues);
          if (!Array.isArray(field.rules) || field.rules.length === 0 || field.rules.length > 5) {
            issues.push({ path: `${fieldPath}.rules`, message: "must define 1-5 rules" });
            return;
          }
          field.rules.forEach((rule, ruleIndex) => {
            const rulePath = `${fieldPath}.rules[${ruleIndex}]`;
            if (!isRecord(rule) || !["required", "email", "minLength", "pattern"].includes(String(rule.kind))) {
              issues.push({ path: rulePath, message: "uses an unsupported validation rule" });
            } else {
              if (!text(rule.message, 180)) issues.push({ path: `${rulePath}.message`, message: "must include an accessible error message" });
              if (rule.kind === "minLength" && (typeof rule.value !== "number" || rule.value < 1 || rule.value > 500)) {
                issues.push({ path: `${rulePath}.value`, message: "must be a number between 1 and 500" });
              }
              if (rule.kind === "pattern" && (!text(rule.value, 120) || UNSAFE_VALUE.test(String(rule.value)))) {
                issues.push({ path: `${rulePath}.value`, message: "must be a safe regular expression" });
              } else if (rule.kind === "pattern") {
                try {
                  if (UNSAFE_PATTERN.test(String(rule.value))) throw new Error("unsafe pattern");
                  new RegExp(String(rule.value));
                } catch {
                  issues.push({ path: `${rulePath}.value`, message: "must be a bounded regular expression without lookarounds, backreferences, or nested quantifiers" });
                }
              }
            }
          });
        });
      }
    }
    if (type === "keyboardNavigation") {
      checkSelector(value.container, `${base}.container`, issues);
      checkSelector(value.items, `${base}.items`, issues);
      if (!["horizontal", "vertical"].includes(String(value.orientation))) {
        issues.push({ path: `${base}.orientation`, message: "must be horizontal or vertical" });
      }
    }
    if (type === "collectionFilter") {
      checkSelector(value.items, `${base}.items`, issues);
      if (!text(value.title, 80)) issues.push({ path: `${base}.title`, message: "must be a concise navigator title" });
      if (!text(value.description, 180)) issues.push({ path: `${base}.description`, message: "must explain what the navigator changes" });
      if (!isRecord(value.search)) {
        issues.push({ path: `${base}.search`, message: "must define an accessible search control" });
      } else {
        if (!text(value.search.label, 80)) issues.push({ path: `${base}.search.label`, message: "must label the search control" });
        if (value.search.placeholder !== void 0 && !text(value.search.placeholder, 100)) {
          issues.push({ path: `${base}.search.placeholder`, message: "must be concise when provided" });
        }
        if (!Array.isArray(value.search.attributes) || value.search.attributes.length === 0 || value.search.attributes.length > 6) {
          issues.push({ path: `${base}.search.attributes`, message: "must list 1-6 data attributes" });
        } else {
          value.search.attributes.forEach((attribute, attributeIndex) => {
            if (typeof attribute !== "string" || !SAFE_DATA_ATTRIBUTE.test(attribute)) {
              issues.push({ path: `${base}.search.attributes[${attributeIndex}]`, message: "must be a safe data-* attribute" });
            }
          });
        }
      }
      if (!Array.isArray(value.filters) || value.filters.length === 0 || value.filters.length > 6) {
        issues.push({ path: `${base}.filters`, message: "must define 1-6 safe filters" });
      } else {
        value.filters.forEach((filter, filterIndex) => {
          const filterPath = `${base}.filters[${filterIndex}]`;
          if (!isRecord(filter)) {
            issues.push({ path: filterPath, message: "must be an object" });
            return;
          }
          if (!text(filter.id, 40) || !SAFE_TOKEN.test(String(filter.id))) issues.push({ path: `${filterPath}.id`, message: "must be a stable filter id" });
          if (!text(filter.label, 80)) issues.push({ path: `${filterPath}.label`, message: "must label the filter" });
          if (typeof filter.attribute !== "string" || !SAFE_DATA_ATTRIBUTE.test(filter.attribute)) {
            issues.push({ path: `${filterPath}.attribute`, message: "must read one safe data-* attribute" });
          }
          if (!Array.isArray(filter.options) || filter.options.length === 0 || filter.options.length > 12) {
            issues.push({ path: `${filterPath}.options`, message: "must define 1-12 options" });
            return;
          }
          filter.options.forEach((option, optionIndex) => {
            const optionPath = `${filterPath}.options[${optionIndex}]`;
            if (!isRecord(option) || !text(option.label, 60) || !text(option.value, 40) || !SAFE_TOKEN.test(String(option.value))) {
              issues.push({ path: optionPath, message: "must contain a safe value and visible label" });
            }
          });
        });
      }
      if (value.persist !== void 0) {
        if (!isRecord(value.persist)) {
          issues.push({ path: `${base}.persist`, message: "must define a bounded local preference receipt" });
        } else {
          if (!text(value.persist.key, 80) || !/^[a-z0-9._-]+$/i.test(String(value.persist.key))) {
            issues.push({ path: `${base}.persist.key`, message: "must be a stable storage key" });
          }
          if (!Number.isInteger(value.persist.ttlMinutes) || Number(value.persist.ttlMinutes) < 5 || Number(value.persist.ttlMinutes) > 10080) {
            issues.push({ path: `${base}.persist.ttlMinutes`, message: "must expire between 5 minutes and 7 days" });
          }
        }
      }
    }
    if (type === "collectionCompare") {
      checkSelector(value.items, `${base}.items`, issues);
      if (!text(value.title, 80)) issues.push({ path: `${base}.title`, message: "must be a concise comparison title" });
      if (!text(value.description, 180)) issues.push({ path: `${base}.description`, message: "must explain the comparison feature" });
      if (typeof value.itemTitleAttribute !== "string" || !SAFE_DATA_ATTRIBUTE.test(value.itemTitleAttribute)) {
        issues.push({ path: `${base}.itemTitleAttribute`, message: "must read one safe data-* attribute" });
      }
      if (!Number.isInteger(value.maxItems) || Number(value.maxItems) < 2 || Number(value.maxItems) > 4) {
        issues.push({ path: `${base}.maxItems`, message: "must allow comparison of 2-4 items" });
      }
      if (!Array.isArray(value.fields) || value.fields.length < 2 || value.fields.length > 8) {
        issues.push({ path: `${base}.fields`, message: "must define 2-8 comparison fields" });
      } else {
        value.fields.forEach((field, fieldIndex) => {
          const fieldPath = `${base}.fields[${fieldIndex}]`;
          if (!isRecord(field)) {
            issues.push({ path: fieldPath, message: "must be an object" });
            return;
          }
          if (!text(field.id, 40) || !SAFE_TOKEN.test(String(field.id))) issues.push({ path: `${fieldPath}.id`, message: "must be a stable field id" });
          if (!text(field.label, 80)) issues.push({ path: `${fieldPath}.label`, message: "must label the comparison field" });
          if (typeof field.attribute !== "string" || !SAFE_DATA_ATTRIBUTE.test(field.attribute)) {
            issues.push({ path: `${fieldPath}.attribute`, message: "must read one safe data-* attribute" });
          }
          if (!Array.isArray(field.values) || field.values.length === 0 || field.values.length > 16) {
            issues.push({ path: `${fieldPath}.values`, message: "must define 1-16 bounded display values" });
            return;
          }
          field.values.forEach((option, optionIndex) => {
            const optionPath = `${fieldPath}.values[${optionIndex}]`;
            if (!isRecord(option) || !text(option.label, 60) || !text(option.value, 40) || !SAFE_TOKEN.test(String(option.value))) {
              issues.push({ path: optionPath, message: "must contain a safe value and visible label" });
            }
          });
          const optionValues = field.values.filter(isRecord).map((option) => option.value).filter((option) => typeof option === "string");
          if (new Set(optionValues).size !== optionValues.length) issues.push({ path: `${fieldPath}.values`, message: "display values must be unique" });
        });
        const fieldIds = value.fields.filter(isRecord).map((field) => field.id).filter((field) => typeof field === "string");
        if (new Set(fieldIds).size !== fieldIds.length) issues.push({ path: `${base}.fields`, message: "comparison field ids must be unique" });
      }
    }
    if (type === "tableColumnFilter") {
      const allowed = /* @__PURE__ */ new Set(["id", "type", "selector", "headerSelector", "rowSelector", "headerText", "markerSelector", "tableLabel", "columnLabel", "markerLabel", "collapseOtherColumns"]);
      Object.keys(value).forEach((key) => {
        if (!allowed.has(key)) issues.push({ path: `${base}.${key}`, message: "is not allowed for a bounded table filter" });
      });
      checkSelector(value.headerSelector, `${base}.headerSelector`, issues);
      checkSelector(value.rowSelector, `${base}.rowSelector`, issues);
      checkSelector(value.markerSelector, `${base}.markerSelector`, issues);
      if (!text(value.headerText, 80) || String(value.headerText) !== String(value.headerText).replace(/\s+/g, " ").trim()) {
        issues.push({ path: `${base}.headerText`, message: "must be an exact normalized public header under 80 characters" });
      }
      for (const key of ["tableLabel", "columnLabel", "markerLabel"]) {
        if (!text(value[key], 160) || UNSAFE_VALUE.test(String(value[key]))) {
          issues.push({ path: `${base}.${key}`, message: "must be a safe accessible label under 160 characters" });
        }
      }
      if (value.collapseOtherColumns !== true) {
        issues.push({ path: `${base}.collapseOtherColumns`, message: "must be true for a focused bounded table view" });
      }
    }
    if (type === "publicTableSearch") {
      const allowed = /* @__PURE__ */ new Set(["id", "type", "selector", "rowSelector", "headerText", "title", "description", "searchLabel", "placeholder", "tableLabel", "maxTables", "maxRows"]);
      Object.keys(value).forEach((key) => {
        if (!allowed.has(key)) issues.push({ path: `${base}.${key}`, message: "is not allowed for bounded public-table search" });
      });
      checkSelector(value.rowSelector, `${base}.rowSelector`, issues);
      if (!text(value.headerText, 80) || String(value.headerText) !== String(value.headerText).replace(/\s+/g, " ").trim()) {
        issues.push({ path: `${base}.headerText`, message: "must be an exact normalized public header under 80 characters" });
      }
      for (const key of ["title", "description", "searchLabel", "tableLabel"]) {
        if (!text(value[key], key === "description" ? 180 : 120) || UNSAFE_VALUE.test(String(value[key]))) {
          issues.push({ path: `${base}.${key}`, message: "must be concise safe visible text" });
        }
      }
      if (value.placeholder !== void 0 && (!text(value.placeholder, 100) || UNSAFE_VALUE.test(String(value.placeholder)))) {
        issues.push({ path: `${base}.placeholder`, message: "must be concise safe placeholder text" });
      }
      if (!Number.isInteger(value.maxTables) || Number(value.maxTables) < 1 || Number(value.maxTables) > 5) {
        issues.push({ path: `${base}.maxTables`, message: "must bound the feature to 1-5 tables" });
      }
      if (!Number.isInteger(value.maxRows) || Number(value.maxRows) < 1 || Number(value.maxRows) > 300) {
        issues.push({ path: `${base}.maxRows`, message: "must bound the feature to 1-300 public rows" });
      }
    }
  }
  function validatePatch(value) {
    const issues = [];
    const warnings = [];
    if (!isRecord(value)) return { ok: false, issues: [{ path: "$", message: "patch must be a JSON object" }], warnings };
    if (value.schemaVersion !== 1) issues.push({ path: "schemaVersion", message: "must equal 1" });
    if (!text(value.id, 80) || !SAFE_ID.test(String(value.id))) issues.push({ path: "id", message: "must be a stable lowercase patch id" });
    if (!text(value.name, 80)) issues.push({ path: "name", message: "must be 1-80 characters" });
    if (!text(value.summary, 240)) issues.push({ path: "summary", message: "must be 1-240 characters" });
    if (!text(value.version, 40) || !SAFE_VERSION.test(String(value.version))) issues.push({ path: "version", message: "must be semantic version syntax" });
    if (!isRecord(value.author) || !text(value.author.name, 80)) issues.push({ path: "author.name", message: "must identify the patch author" });
    else if (value.author.verified !== void 0 && typeof value.author.verified !== "boolean") issues.push({ path: "author.verified", message: "must be a boolean when provided" });
    if (!isRecord(value.match)) {
      issues.push({ path: "match", message: "must define exact hosts and paths" });
    } else {
      if (!Array.isArray(value.match.hosts) || value.match.hosts.length === 0 || value.match.hosts.length > 12) {
        issues.push({ path: "match.hosts", message: "must list 1-12 hosts" });
      } else {
        value.match.hosts.forEach((host, index) => {
          if (typeof host !== "string" || !SAFE_HOST.test(host)) issues.push({ path: `match.hosts[${index}]`, message: "must be an exact host or one leftmost subdomain wildcard" });
        });
      }
      if (!Array.isArray(value.match.paths) || value.match.paths.length === 0 || value.match.paths.length > 20) {
        issues.push({ path: "match.paths", message: "must list 1-20 pathname patterns" });
      } else {
        value.match.paths.forEach((path, index) => {
          if (typeof path !== "string" || !SAFE_PATH.test(path) || path.includes("..") || path.slice(0, -1).includes("*")) {
            issues.push({ path: `match.paths[${index}]`, message: "must be a safe pathname with at most one final wildcard" });
          }
        });
      }
    }
    if (!Array.isArray(value.capabilities) || value.capabilities.length === 0) {
      issues.push({ path: "capabilities", message: "must declare at least one capability" });
    } else {
      value.capabilities.forEach((capability, index) => {
        if (!CAPABILITIES.has(capability)) issues.push({ path: `capabilities[${index}]`, message: "is not a recognized capability" });
      });
    }
    if (!Array.isArray(value.operations) || value.operations.length === 0 || value.operations.length > 100) {
      issues.push({ path: "operations", message: "must contain 1-100 constrained operations" });
    } else {
      value.operations.forEach((operation, index) => checkOperation(operation, index, issues));
      const ids = value.operations.map((operation) => isRecord(operation) ? operation.id : void 0).filter(Boolean);
      if (new Set(ids).size !== ids.length) issues.push({ path: "operations", message: "operation ids must be unique" });
      if (Array.isArray(value.capabilities)) {
        const declared = new Set(value.capabilities);
        requiredCapabilities(value.operations).forEach((capability) => {
          if (!declared.has(capability)) issues.push({ path: "capabilities", message: `must declare ${capability} for the requested operations` });
        });
      }
    }
    if (!Array.isArray(value.verify) || value.verify.length === 0) {
      warnings.push({ path: "verify", message: "published patches should include selector assertions" });
    } else if (value.verify.length > 50) {
      issues.push({ path: "verify", message: "must contain no more than 50 assertions" });
    } else {
      value.verify.forEach((assertion, index) => {
        const path = `verify[${index}]`;
        if (!isRecord(assertion) || !["exists", "attribute"].includes(String(assertion.type))) {
          issues.push({ path, message: "must be an exists or attribute assertion" });
          return;
        }
        checkSelector(assertion.selector, `${path}.selector`, issues);
        if (assertion.type === "exists") {
          for (const bound of ["min", "max"]) {
            if (assertion[bound] !== void 0 && (!Number.isInteger(assertion[bound]) || Number(assertion[bound]) < 0 || Number(assertion[bound]) > 100)) {
              issues.push({ path: `${path}.${bound}`, message: "must be an integer between 0 and 100" });
            }
          }
          if (typeof assertion.min === "number" && typeof assertion.max === "number" && assertion.min > assertion.max) {
            issues.push({ path, message: "minimum selector count may not exceed maximum" });
          }
        } else {
          if (!text(assertion.name, 80) || !/^[a-z][a-z0-9:._-]*$/i.test(String(assertion.name))) issues.push({ path: `${path}.name`, message: "must be a safe attribute name" });
          if (typeof assertion.value !== "string" || assertion.value.length > 240 || UNSAFE_VALUE.test(assertion.value)) issues.push({ path: `${path}.value`, message: "must be a safe assertion value" });
        }
      });
    }
    if (!text(value.changelog, 500)) issues.push({ path: "changelog", message: "must describe this version" });
    if (issues.length > 0) return { ok: false, issues, warnings };
    return { ok: true, patch: value, warnings };
  }
  function requiredCapabilities(operations) {
    const result = /* @__PURE__ */ new Set();
    for (const operation of operations) {
      if (operation.type === "style") result.add("layout");
      if (operation.type === "attributes") result.add("accessibility");
      if (operation.type === "hide") result.add("hide-elements");
      if (operation.type === "move") result.add("reorganize");
      if (operation.type === "persistForm") result.add("local-storage");
      if (operation.type === "validation") result.add("validation");
      if (operation.type === "keyboardNavigation") result.add("keyboard-navigation");
      if (operation.type === "collectionFilter") {
        result.add("content-filter");
        result.add("accessibility");
        result.add("keyboard-navigation");
        if (operation.persist) result.add("local-storage");
      }
      if (operation.type === "collectionCompare") {
        result.add("content-compare");
        result.add("accessibility");
        result.add("keyboard-navigation");
      }
      if (operation.type === "tableColumnFilter") {
        result.add("content-filter");
        result.add("hide-elements");
        result.add("accessibility");
      }
      if (operation.type === "publicTableSearch") {
        result.add("content-filter");
        result.add("accessibility");
        result.add("keyboard-navigation");
      }
    }
    return [...result];
  }

  // src/core/registry.ts
  function versionParts(version) {
    return version.split(/[.-]/).slice(0, 3).map((part) => Number.parseInt(part, 10) || 0);
  }
  function comparePatchVersions(left, right) {
    const a = versionParts(left);
    const b = versionParts(right);
    for (let index = 0; index < 3; index += 1) {
      if (a[index] !== b[index]) return a[index] - b[index];
    }
    return left.localeCompare(right);
  }
  function buildPatchCatalog(bundled2, stored) {
    const byId = /* @__PURE__ */ new Map();
    let rejected = 0;
    for (const patch of bundled2) {
      const validation = validatePatch(patch);
      if (!validation.ok) {
        rejected += 1;
        continue;
      }
      byId.set(patch.id, { patch, source: "bundled" });
    }
    if (stored && typeof stored === "object" && !Array.isArray(stored)) {
      for (const candidate of Object.values(stored)) {
        const validation = validatePatch(candidate);
        if (!validation.ok) {
          rejected += 1;
          continue;
        }
        const current = byId.get(validation.patch.id);
        if (!current || comparePatchVersions(validation.patch.version, current.patch.version) >= 0) {
          byId.set(validation.patch.id, { patch: validation.patch, source: "local" });
        }
      }
    }
    return { patches: [...byId.values()], rejected };
  }
  function matchingCatalogPatches(catalog, url) {
    return catalog.filter(({ patch }) => patchMatchesUrl(patch, url));
  }

  // src/extension/content.ts
  var bundled = [civic_apply_patch_the_web_default];
  var matches = [];
  async function initialize() {
    const stored = await chrome.storage.local.get(["enabledPatches", "installedPatches"]);
    const enabledPatches = stored.enabledPatches ?? {};
    const catalog = buildPatchCatalog(bundled, stored.installedPatches);
    const matching = matchingCatalogPatches(catalog.patches, new URL(location.href));
    matches = matching.map(({ patch, source }) => {
      const enabled = Boolean(enabledPatches[patch.id]);
      const health = enabled ? applyPatch(patch) : null;
      if (health) void chrome.storage.local.set({ [`health:${patch.id}:${location.hostname}`]: health });
      return {
        enabled,
        health,
        source,
        patch: {
          id: patch.id,
          name: patch.name,
          summary: patch.summary,
          version: patch.version,
          capabilities: patch.capabilities,
          author: patch.author,
          match: patch.match,
          operationCount: patch.operations.length
        }
      };
    });
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "PATCH_THE_WEB_GET_STATE") {
      sendResponse({ matched: matches.length > 0, matches });
    }
  });
  void initialize();
})();
//# sourceMappingURL=content.js.map
